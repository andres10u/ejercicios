#4 Validación de Nota Positiva

nota = float(input("Ingrese una nota entre 0.0 y 5.0: "))

while nota < 0 or nota > 5:
    print("Nota inválida.")
    nota = float(input("Ingrese nuevamente la nota: "))

print("Nota registrada:", nota)
