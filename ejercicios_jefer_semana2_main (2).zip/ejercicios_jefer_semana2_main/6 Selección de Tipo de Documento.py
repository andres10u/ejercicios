#6 Selección de Tipo de Documento
while True:
    tipo = input("Ingrese su tipo de documento (CC, TI, CE): ").upper()
    
    if tipo in ["CC", "TI", "CE"]:
        print(f"Documento aceptado: {tipo}")
        break
    else:
        print("Documento inválido. Intente nuevamente.")