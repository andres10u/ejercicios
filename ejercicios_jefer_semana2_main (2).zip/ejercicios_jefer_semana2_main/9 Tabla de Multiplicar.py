#9 Tabla de Multiplicar
numero = int(input("Ingrese un número entero: "))
i = 1

while i <= 10:
    print(f"{numero} X {i} = {numero * i}")
    i += 1